<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses. 
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 * 
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2018 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

if (!defined('_PS_VERSION_'))
	exit;
include_once(_PS_MODULE_DIR_.'ets_pres2presconnector/classes/DataExport.php'); 
include_once(_PS_MODULE_DIR_.'ets_pres2presconnector/classes/ExtraExport.php');   
if (version_compare(_PS_VERSION_, '1.5', '<') && !class_exists('Context'))
    require_once (_PS_MODULE_DIR_ .'/ets_pres2presconnector/backward_compatibility/Context.php');
class Ets_pres2presconnector extends Module
{
    private $errorMessage;
    public $configs;
    public $baseAdminPath;
    private $_html;
    public $url_module;
    public $errors = array();
    public $tables;
    public $data_exports='';
    public $divide_file=1;
    public $number_record=500;
    public $pres_version;
    public $context;
    public function __construct()
	{
		$this->name = 'ets_pres2presconnector';
		$this->tab = 'front_office_features';
		$this->version = '1.0.7';
		$this->author = 'ETS-Soft';
		$this->need_instance = 0;
		$this->secure_key = Tools::encrypt($this->name);        
		$this->bootstrap = true;
        $this->module_key = '8c4686a2fe6d643fe0dea93e2e0a7082';
        if(version_compare(_PS_VERSION_, '1.7', '>='))
            $this->pres_version=1.7;
        elseif(version_compare(_PS_VERSION_, '1.7', '<') && version_compare(_PS_VERSION_, '1.6', '>=') )
            $this->pres_version=1.6;
        elseif(version_compare(_PS_VERSION_, '1.6', '<') && version_compare(_PS_VERSION_, '1.5', '>=') )
            $this->pres_version=1.5;
        elseif(version_compare(_PS_VERSION_, '1.5', '<') && version_compare(_PS_VERSION_, '1.4', '>=') )
            $this->pres_version=1.4;
        else
            $this->pres_version=1.3;
        if($this->pres_version<=1.4)
            $this->data_exports='employees,categories,customers,manufactures,suppliers,carriers,vouchers,products,orders,cms_cateogories,cms,messages';
        else
        {
            if(Tools::isSubmit('exportallshop'))
                $this->data_exports='shops,employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,cms_cateogories,cms,messages';
            else
                $this->data_exports='employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,cms_cateogories,cms,messages';
        }
            
		parent::__construct();
        $this->context = Context::getContext();
        $this->url_module = $this->_path;
        $this->displayName = $this->l('Prestashop connector');
		$this->description = $this->l('Connect Prestashop websites for migration purpose!');
    }
    /**
	 * @see Module::install()
	 */
    public function install()
	{
	   Configuration::updateValue('ETS_PRES2PRES_TOCKEN',$this->genSecure(6));
       Configuration::updateValue('ETS_PRES2PRES_CONNECTOR',1);
	   if($this->pres_version==1.4)
       {
            if(parent::install()&&$this->registerHook('header'))
            {
                chmod(dirname(__FILE__).'/connector.php',0644);
                chmod(dirname(__FILE__).'/../ets_pres2presconnector',0755);
                return true;
            }
       }
	   else
       {
            if(parent::install()        
            && $this->registerHook('displayBackOfficeHeader')&& $this->registerHook('header')
            && $this->registerHook('displayBackOfficeFooter'))
            {
                chmod(dirname(__FILE__).'/connector.php',0644);
                chmod(dirname(__FILE__).'/../ets_pres2presconnector',0755);
                return true;
            }
            
       }
       return false;        
    }
    /**
	 * @see Module::uninstall()
	 */
	public function uninstall()
	{
        Configuration::deleteByName('ETS_PRES2PRES_TOCKEN');
        Configuration::deleteByName('ETS_PRES2PRES_CONNECTOR');
        return parent::uninstall();
    }    
    public function hookHeader()
    {
        if(Tools::isSubmit('presconnector') && Tools::getValue('pres2prestocken')==Configuration::get('ETS_PRES2PRES_TOCKEN') && Configuration::get('ETS_PRES2PRES_CONNECTOR'))
            $this->processExport();
    }  
    public function getContent()
	{
        if(!$this->active)
            return '';
        $errors=array();
        $html ='';
        @ini_set('display_errors', 'on');
        $context=Context::getContext();
        if(Tools::isSubmit('btnSubmit'))
        {
            if(!Tools::getValue('ETS_PRES2PRES_TOCKEN'))
            {
                $errors[]=$this->l('Secure access token is required');
                $html .=$this->displayError($errors);
            }
            else
            {
                Configuration::updateValue('ETS_PRES2PRES_CONNECTOR',Tools::getValue('ETS_PRES2PRES_CONNECTOR'));
                Configuration::updateValue('ETS_PRES2PRES_TOCKEN',Tools::getValue('ETS_PRES2PRES_TOCKEN'));
                $html .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }
        if(Tools::isSubmit('ajax_percentage_export'))
        {
            $this->ajaxPercentageExport();
        }
        if(Tools::isSubmit('btnSubmitDownload'))
        {
            if($this->pres_version<=1.4)
                $this->data_exports='employees,categories,customers,manufactures,suppliers,carriers,vouchers,products,orders,cms_cateogories,cms,messages';
            else
            {
                if(Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL)
                    $this->data_exports='shops,employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,cms_cateogories,cms,messages';
                else
                    $this->data_exports='employees,categories,customers,manufactures,suppliers,carriers,cart_rules,catelog_rules,products,orders,cms_cateogories,cms,messages';
            }
            $this->processExport();
        } 
        if($this->pres_version==1.4)
        {
            $connector_url=(Configuration::get('PS_SSL_ENABLED_EVERYWHERE')?'https://'.Configuration::get('PS_SHOP_DOMAIN_SSL'):'http://'.Configuration::get('PS_SHOP_DOMAIN')).__PS_BASE_URI__.'modules/'.$this->name.'/connector.php';
        }
        else
        {
            $connector_url =(Configuration::get('PS_SSL_ENABLED_EVERYWHERE')?'https://':'http://').$context->shop->domain.$context->shop->getBaseURI().'modules/'.$this->name.'/connector.php'.(Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL?'?exportallshop=1':'');
        }
        $context->smarty->assign(
            array(
                'ETS_PRES2PRES_CONNECTOR'=> Tools::getValue('ETS_PRES2PRES_CONNECTOR',Configuration::get('ETS_PRES2PRES_CONNECTOR')),
                'ETS_PRES2PRES_TOCKEN' => Tools::getValue('ETS_PRES2PRES_TOCKEN',Configuration::get('ETS_PRES2PRES_TOCKEN')),
                'connector_url' => $connector_url,
                'dir_path'=> $this->_path,
                'pres_version'=>$this->pres_version,
            )
        );    
        return $html.$this->display(__FILE__,'views/templates/hook/admin.tpl');
    }
    public function hookDisplayBackOfficeHeader()
    {
        $this->context->controller->addCSS($this->_path.'views/css/admin-icon.css','all');
        if(Tools::isSubmit('controller') && Tools::getValue('controller')=='AdminModules' && Tools::getValue('configure')==$this->name )
        {
            $this->context->controller->addCSS($this->_path.'views/css/pres2presconnector.admin.css','all');
            if($this->pres_version==1.5)
            {
                $this->context->controller->addCSS($this->_path.'views/css/font-awesome.css','all');
                $this->context->controller->addCSS($this->_path.'views/css/fic14.css','all');
            }
            $this->context->controller->addJquery();    
            $this->context->controller->addJS($this->_path.'views/js/pres2presconnector.admin.js');
            $this->context->controller->addJS($this->_path.'views/js/easytimer.min.js');
            $this->context->controller->addJS($this->_path.'views/js/tree.js');
        }
    }
  
    public function displayError($error)
    {
        $this->context->smarty->assign(
            array(
                'ybc_errors'=>$error,
            )
        );
        return $this->display(__FILE__,'views/templates/hook/errors.tpl');
    }
    public function exportContent($save=true)
    {
        $data_exports=explode(',',$this->data_exports);
        $contents =array();
        $totaldatas=array();
        if(in_array('shops',$data_exports))
        {
            $countShop = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'shop');
            $contents[]=array(
                'title'=>$this->l('Shops:'), 
                'count'=>$countShop, 
            );
            $totaldatas['shops'] =(int)$countShop;
        }
        if(in_array('employees',$data_exports))
        {
            $countEmployee = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'employee');
            $contents[]=array(
                'title'=>$this->l('Employees:'), 
                'count'=>$countEmployee, 
            );
            $totaldatas['employees'] =(int)$countEmployee;
            
        }
        if(in_array('categories',$data_exports))
        {
            $countCategory = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'category');
            $contents[]=array(
                'title'=>$this->l('Categories:'), 
                'count'=>$countCategory, 
            );
            $totaldatas['categories'] =(int)$countCategory;
        }
        if(in_array('products',$data_exports))
        {
            $countProduct= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product');
            $contents[]=array(
                'title'=>$this->l('Products:'), 
                'count'=>$countProduct, 
            );
            $totaldatas['products'] =(int)$countProduct;
        }
        if(in_array('customers',$data_exports))
        {
            $countCustomer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer WHERE deleted=0');
            $contents[]=array(
                'title'=>$this->l('Customers:'), 
                'count'=>$countCustomer, 
            );
            $totaldatas['customers'] =(int)$countCustomer;
        }
        if(in_array('orders',$data_exports))
        {
            $countOrder = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'orders');
            $contents[]=array(
                'title'=>$this->l('Orders:'), 
                'count'=>$countOrder, 
            );
            $totaldatas['orders'] =(int)$countOrder;
        }
        if(in_array('manufactures',$data_exports))
        {
            $countManufacturer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'manufacturer');
            $contents[]=array(
                'title'=>$this->l('Manufacturers:'), 
                'count'=>$countManufacturer, 
            );
            $totaldatas['manufactures'] =(int)$countManufacturer;
        }
        if(in_array('suppliers',$data_exports))
        {
            $countSupplier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'supplier');
            $contents[]=array(
                'title'=>$this->l('Suppliers:'), 
                'count'=>$countSupplier, 
            );
            $totaldatas['suppliers'] =(int)$countSupplier;
        }
        if(in_array('carriers',$data_exports))
        {
            $countCarrier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'carrier WHERE deleted=0');
            $contents[]=array(
                'title'=>$this->l('Carriers:'), 
                'count'=>$countCarrier, 
            );
            $totaldatas['carriers'] =(int)$countCarrier;
        }
        if(in_array('cart_rules',$data_exports))
        {
            $countCartRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cart_rule');
            $contents[]=array(
                'title'=>$this->l('Cart rules:'), 
                'count'=>$countCartRule, 
            );
            $totaldatas['cart_rules'] =(int)$countCartRule;
        }
        if(in_array('catelog_rules',$data_exports))
        {
            $countSpecificPriceRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'specific_price_rule');
            $contents[]=array(
                'title'=>$this->l('Catelog rules:'), 
                'count'=>$countSpecificPriceRule, 
            );
            $totaldatas['catelog_rules'] =(int)$countSpecificPriceRule;
        }
        if(in_array('vouchers',$data_exports))
        {
            $countVoucher = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'discount');
            $contents[]=array(
                'title'=>$this->l('Vouchers:'), 
                'count'=>$countVoucher, 
            );
            $totaldatas['vouchers'] =(int)$countVoucher;
        }
        if(in_array('cms_cateogories',$data_exports))
        {
            $countcmscategory = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms_category');
            $contents[]=array(
                'title'=>$this->l('CMS categories:'), 
                'count'=>$countcmscategory, 
            );
            $totaldatas['cms_cateogories'] =(int)$countcmscategory;
        }
        if(in_array('cms',$data_exports))
        {
            $countcms = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms');
            $contents[]=array(
                'title'=>$this->l('CMSs:'), 
                'count'=>$countcms, 
            );
            $totaldatas['cms'] =(int)$countcms;
        }
        if(in_array('messages',$data_exports))
        {
            $countMessage = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer_thread');
            $contents[]=array(
                'title'=>$this->l('Contact form messages:'), 
                'count'=>$countMessage, 
            );
            $totaldatas['messages'] =(int)$countMessage;
        }
        if($save)
        {
            $this->context->smarty->assign(
                array(
                    'contents'=>$contents
                )
            );
            return $this->display(__FILE__,'views/templates/hook/contents.tpl');
        } 
        else
            return $totaldatas;
    }  
    public function processExport()
    {
        if($this->pres_version==1.4)
             $this->exportDataXML14();
        else   
            $this->exportDataXML();
    }
    public function exportDataXML()
    {
        $export= new Pres2PresConnectorExport();
        $extra_export= new Pres2PresConnectorExtraExport();
        $cacheDir = dirname(__FILE__).'/cache/export/';
        if(Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        else{
            if(!Tools::getValue('submitExportReload'))
            {
                $this->context->cookie->zip_file_name='';
                $this->context->cookie->export_sucss='';
                $this->context->cookie->write();
            }
            $cacheDir = dirname(__FILE__).'/cache/export/';
            if(isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name)
            {
                $zip_file_name =$this->context->cookie->zip_file_name;
            }
            else
            {
                $zip_file_name = 'oc2m_data_'.$this->genSecure(7);
    
                $this->context->cookie->zip_file_name=$zip_file_name;
    
                $this->context->cookie->write();
                die('x2');
            }
        }
        $dir = $cacheDir.$zip_file_name;
        
        if(!is_dir($dir)){
            @mkdir($dir, 0777);
            file_put_contents($dir.'/export.txt','0');
            $export->total_export=0;
        }
        else
            $export->total_export = (int)trim(file_get_contents($dir.'/export.txt'));
        if(file_exists($cacheDir.$zip_file_name.'.zip'))
        {
            $this->deleteForderXml($zip_file_name);
        }
        $data_exports=explode(',',$this->data_exports);
        $multishop = in_array('shops',$data_exports);
        
        file_put_contents($dir.'/DataInfo.xml',$extra_export->exportInfo($dir));
        if ($data_exports) {
            if($multishop)
            {
                if(!$export->addFileXMl($dir,'ShopGroup',ShopGroup::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create ShopGroup.xml');
                if(!$export->addFileXMl($dir,'Shop',Shop::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Shop.xml');
                if(!$export->addFileXMl($dir,'ShopUrl',ShopUrl::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create ShopUrl.xml');
            }
            if(!$export->addFileXMl($dir,'Language',Language::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Language.xml');
            if(!$export->addFileXMl($dir,'Currency',Currency::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Currency.xml');
            if(!$export->addFileXMl($dir,'Zone',Zone::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Zone.xml');
            if(!$export->addFileXMl($dir,'Country',Country::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Country.xml');
            if(!$export->addFileXMl($dir,'State',State::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create State.xml');
            if(!$export->addFileXMl($dir,'Employee',Employee::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Employee.xml');
            if(in_array('categories',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Group',Group::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Group.xml');
                if(!$this->addCategoryFileXMl($dir,$multishop))
                    $this->_errors[] = $this->l('Cannot create Category.xml');
            }
            if(in_array('customers',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Group',Group::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Group.xml');
                if(!$export->addFileXMl($dir,'Customer',Customer::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Customer.xml');
                if (!$export->addFileXMl14($dir,'customergroup','customer_group')) {
                   $this->_errors[] = $this->l('Cannot create customergroup.xml');
                }
                if(!$export->addFileXMl($dir,'Address',Address::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Address.xml');
            }
            if(in_array('manufactures',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Manufacturer',Manufacturer::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Manufacturer.xml');
            }
            if(in_array('suppliers',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Supplier',Supplier::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Supplier.xml');
            }
            if(in_array('carriers',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Carrier',Carrier::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Carrier.xml');
                if (!$export->addFileXMl14($dir,'carrierzone','carrier_zone')) {
                   $this->_errors[] = $this->l('Cannot create carrierzone.xml'); 
                }
                if(!$export->addFileXMl($dir,'RangePrice',RangePrice::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create RangePrice.xml');
                if(!$export->addFileXMl($dir,'RangeWeight',RangeWeight::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create RangeWeight.xml');
                if(!$export->addFileXMl($dir,'Delivery',Delivery::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Delivery.xml');
            }
            if(in_array('cart_rules',$data_exports))
            {
                if(!$export->addFileXMl($dir,'CartRule',CartRule::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create CartRule.xml');
            }
            if(in_array('catelog_rules',$data_exports))
            {
                if(!$export->addFileXMl($dir,'SpecificPriceRule',SpecificPriceRule::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create SpecificPriceRule.xml');            
            }
            if(in_array('products',$data_exports))
            {
                if (!$export->addFileXMl14($dir,'categoryproduct','category_product')) {
                   $this->_errors[] = $this->l('Cannot create categoryproduct.xml');  //extra
                }
                if(!$export->addFileXMl($dir,'Product',Product::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Product.xml');
                if(!$export->addFileXMl($dir,'Tag',Tag::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create tag.xml');
                if(!$export->addFileXMl($dir,'Image',Image::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Image.xml');
                if(!$export->addFileXMl($dir,'Combination',Combination::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Combination.xml');
                if(!$export->addFileXMl($dir,'AttributeGroup',AttributeGroup::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create AttributeGroup.xml');
                if(!$export->addFileXMl($dir,'Attribute',Attribute::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Attribute.xml');
                if (!$export->addFileXMl14($dir,'productattributecombination','product_attribute_combination')) {
                   $this->_errors[] = $this->l('Cannot create productattributecombination.xml'); //extra
                }
                if (!$export->addFileXMl14($dir,'productattributeimage','product_attribute_image')) {
                   $this->_errors[] = $this->l('Cannot create productattributeimage.xml'); //extra
                }
                if (!$export->addFileXMl14($dir,'producttag','product_tag')) {
                   $this->_errors[] = $this->l('Cannot create producttag.xml'); //extra
                }
                if(!$export->addFileXMl($dir,'Feature',Feature::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Feature.xml');
                if(!$export->addFileXMl($dir,'FeatureValue',FeatureValue::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create FeatureValue.xml');   
                if (!$export->addFileXMl14($dir,'featureproduct','feature_product')) {
                   $this->_errors[] = $this->l('Cannot create featureproduct.xml'); // extra feature_product;
                }
                if(!$export->addFileXMl($dir,'SpecificPrice',SpecificPrice::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create SpecificPrice.xml');
                if(!$export->addFileXMl($dir,'Tax',Tax::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Tax.xml');
                if(!$export->addFileXMl($dir,'TaxRulesGroup',TaxRulesGroup::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create TaxRulesGroup.xml');
                if(!$export->addFileXMl($dir,'TaxRule',TaxRule::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create TaxRule.xml');
                if (!$export->addFileXMl14($dir,'productsupplier','product_supplier')) {
                   $this->_errors[] = $this->l('Cannot create productsupplier.xml'); // id_tax, id_rules_group
                }
                if(!$export->addFileXMl($dir,'StockAvailable',StockAvailable::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create StockAvailable.xml');
                if(!$export->addFileXMl14($dir,'CustomizationField','customization_field','id_customization_field',true))
                    $this->_errors[]= $this->l('Cannot create CustomizationField.xml');
                if(in_array('carriers',$data_exports))
                {
                    if (!$export->addFileXMl14($dir,'productcarrier','product_carrier')) {
                       $this->_errors[] = $this->l('Cannot create productcarrier.xml'); 
                    }
                }
                if (!$export->addFileXMl14($dir,'accessory','accessory')) {
                   $this->_errors[] = $this->l('Cannot create accessory.xml'); //extra
                }
            }
            if(in_array('orders',$data_exports))
            {
                if(!$export->addFileXMl($dir,'OrderState',OrderState::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderState.xml');
                if(!$export->addFileXMl($dir,'Cart',Cart::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Cart.xml');
                if(!$export->addFileXMl14($dir,'Customization','customization','id_customization'))
                    $this->_errors[]= $this->l('Cannot create CustomizationField.xml');
                if(!$export->addFileXMl14($dir,'customizeddata','customized_data'))
                    $this->_errors[]= $this->l('Cannot create customizeddata.xml');
                if(!$export->addFileXMl($dir,'Order',Order::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Order.xml');
                if(!$export->addFileXMl($dir,'OrderDetail',OrderDetail::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderDetail.xml');
                if(!$export->addFileXMl($dir,'OrderInvoice',OrderInvoice::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderInvoice.xml');
                if(!$export->addFileXMl($dir,'OrderSlip',OrderSlip::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderSlip.xml');
                if(!$export->addFileXMl($dir,'OrderCarrier',OrderCarrier::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderCarrier.xml');
                if(!$export->addFileXMl($dir,'OrderCartRule',OrderCartRule::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderCartRule.xml');
                if(!$export->addFileXMl($dir,'OrderHistory',OrderHistory::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderHistory.xml');
                if(!$export->addFileXMl($dir,'OrderMessage',OrderMessage::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderMessage.xml');
                if(!$export->addFileXMl($dir,'OrderPayment',OrderPayment::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderPayment.xml');
                if(!$export->addFileXMl($dir,'OrderReturn',OrderReturn::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create OrderReturn.xml');
                if(!$export->addFileXMl($dir,'Message',Message::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Message.xml');
            }
            if(in_array('cms_cateogories',$data_exports))
            {
                if(!$export->addFileXMl($dir,'CMSCategory',CMSCategory::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create CMSCategory.xml');
            }
            if(in_array('cms',$data_exports))
            {
                if(!$export->addFileXMl($dir,'CMS',CMS::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create CMS.xml');
            }
            if(in_array('messages',$data_exports))
            {
                if(!$export->addFileXMl($dir,'Contact',Contact::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create Contact.xml');
                if(!$export->addFileXMl($dir,'CustomerThread',CustomerThread::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create CustomerThread.xml');
                if(!$export->addFileXMl($dir,'CustomerMessage',CustomerMessage::$definition,$multishop))
                    $this->_errors[] = $this->l('Cannot create CustomerMessage.xml');
            }
            if(!$this->_errors)
            {
                $this->zipForderXml($zip_file_name);
                $content = $this->exportContent();
                $this->context->cookie->zip_file_name='';
                $this->context->cookie->write();
                $this->deleteForderXml($zip_file_name);
            }
        }
        return $this->_errors;
   }
   public function getBaseLink()
   {
        if($this->pres_version==1.4)
        {
            return 'http://'.Configuration::get('PS_SHOP_DOMAIN').__PS_BASE_URI__;
        }
        return (Configuration::get('PS_SSL_ENABLED_EVERYWHERE')?'https://':'http://').$this->context->shop->domain.$this->context->shop->getBaseURI();
   }
   
   public function exportDataXML14()
   {
        $cacheDir = dirname(__FILE__).'/cache/export/';
        if(Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        else{
            if(!Tools::getValue('submitExportReload'))
            {
                $this->context->cookie->zip_file_name='';
                $this->context->cookie->export_sucss='';
                $this->context->cookie->write();
            }
            $cacheDir = dirname(__FILE__).'/cache/export/';
            if(isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name)
            {
                $zip_file_name =$this->context->cookie->zip_file_name;
            }
            else
            {
                $zip_file_name = 'oc2m_data_'.$this->genSecure(7);
    
                $this->context->cookie->zip_file_name=$zip_file_name;
    
                $this->context->cookie->write();
                die('x2');
            }
        }
        $dir = $cacheDir.$zip_file_name;
        if(!is_dir($dir)){
            @mkdir($dir, 0777);
            file_put_contents($dir.'/export.txt','0');
        }
        if(file_exists($cacheDir.$zip_file_name.'.zip'))
        {
            $this->deleteForderXml($zip_file_name);
        }
        $data_exports=explode(',',$this->data_exports);
        $export= new Pres2PresConnectorExport();
        $extra_export= new Pres2PresConnectorExtraExport();
        file_put_contents($dir.'/DataInfo.xml',$extra_export->exportInfo($dir));
        if ($data_exports) {
            if(!$export->addFileXMl14($dir,'Language','lang','id_lang',false))
                $this->_errors[] = $this->l('Cannot create Language.xml');
            if(!$export->addFileXMl14($dir,'Currency','currency','id_currency',false))
                $this->_errors[] = $this->l('Cannot create Currency.xml');  
            if(!$export->addFileXMl14($dir,'Zone','zone','id_zone',false))
                    $this->_errors[] = $this->l('Cannot create Zone.xml');
            if(!$export->addFileXMl14($dir,'Country','country','id_country',true))
                    $this->_errors[] = $this->l('Cannot create Country.xml');
            if(!$export->addFileXMl14($dir,'State','state','id_state',false))
                    $this->_errors[] = $this->l('Cannot create State.xml');
            if(in_array('employees',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Employee','employee','id_employee',false))
                    $this->_errors[] = $this->l('Cannot create Employee.xml');
            }
            if(in_array('categories',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Group','group','id_group',true))
                    $this->_errors[] = $this->l('Cannot create Group.xml');
                if (!$export->addFileXMl14($dir,'categorygroup','category_group')) {
                   $this->_errors[] = $this->l('Cannot create categorygroup.xml');
                }
                if(!$this->addCategoryFileXMl14($dir,false))
                    $this->_errors[] = $this->l('Cannot create Category.xml');
            }
            if(in_array('customers',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Group','group','id_group',true))
                    $this->_errors[] = $this->l('Cannot create Group.xml');
                if(!$export->addFileXMl14($dir,'Customer','customer','id_customer',false))
                    $this->_errors[] = $this->l('Cannot create Customer.xml');
                if (!$export->addFileXMl14($dir,'customergroup','customer_group')) {
                   $this->_errors[] = $this->l('Cannot create customergroup.xml');
                }
                if(!$export->addFileXMl14($dir,'Address','address','id_address',false))
                    $this->_errors[] = $this->l('Cannot create Address.xml');
            }
            if(in_array('manufactures',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Manufacturer','manufacturer','id_manufacturer',true))
                    $this->_errors[] = $this->l('Cannot create Manufacturer.xml');
            }
            if(in_array('suppliers',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Supplier','supplier','id_supplier',true))
                    $this->_errors[] = $this->l('Cannot create Supplier.xml');
            }
            if(in_array('carriers',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Carrier','carrier','id_carrier',true))
                    $this->_errors[] = $this->l('Cannot create Carrier.xml');
                if (!$export->addFileXMl14($dir,'carrierzone','carrier_zone')) {
                   $this->_errors[] = $this->l('Cannot create carrierzone.xml'); 
                }
                if (!$export->addFileXMl14($dir,'carriergroup','carrier_group')) {
                   $this->_errors[] = $this->l('Cannot create carriergroup.xml'); 
                }
                if(!$export->addFileXMl14($dir,'RangePrice','range_price','id_range_price',false))
                    $this->_errors[] = $this->l('Cannot create RangePrice.xml');
                if(!$export->addFileXMl14($dir,'RangeWeight','range_weight','id_range_weight',false))
                    $this->_errors[] = $this->l('Cannot create RangeWeight.xml');
                if(!$export->addFileXMl14($dir,'Delivery','delivery','id_delivery',false))
                    $this->_errors[] = $this->l('Cannot create Delivery.xml');
            }
            if(in_array('vouchers',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Discount','discount','id_discount',true))
                    $this->_errors[] = $this->l('Cannot create Discount.xml');
                if(!$export->addFileXMl14($dir,'DiscountType','discount_type','id_discount_type',true))
                    $this->_errors[] = $this->l('Cannot create DiscountType.xml');
            }
            if(in_array('products',$data_exports))
            {
                if (!$export->addFileXMl14($dir,'categoryproduct','category_product')) {
                   $this->_errors[] = $this->l('Cannot create categoryproduct.xml');  //extra
                }
                if(!$export->addFileXMl14($dir,'Product','product','id_product',true))
                    $this->_errors[] = $this->l('Cannot create Product.xml');
                if(!$export->addFileXMl14($dir,'Tag','tag','id_tag'))
                    $this->_errors[] = $this->l('Cannot create Tag.xml');
                if(!$export->addFileXMl14($dir,'Image','image','id_image',true))
                    $this->_errors[] = $this->l('Cannot create Image.xml');
                if(!$export->addFileXMl14($dir,'Combination','product_attribute','id_product_attribute',false))
                    $this->_errors[] = $this->l('Cannot create Combination.xml');
                if(!$export->addFileXMl14($dir,'AttributeGroup','attribute_group','id_attribute_group',true))
                    $this->_errors[] = $this->l('Cannot create AttributeGroup.xml');
                if(!$export->addFileXMl14($dir,'Attribute','attribute','id_attribute',true))
                    $this->_errors[] = $this->l('Cannot create Attribute.xml');
                if (!$export->addFileXMl14($dir,'productattributecombination','product_attribute_combination')) {
                   $this->_errors[] = $this->l('Cannot create productattributecombination.xml'); //extra
                }
                if (!$export->addFileXMl14($dir,'productattributeimage','product_attribute_image')) {
                   $this->_errors[] = $this->l('Cannot create productattributeimage.xml'); //extra
                }
                if (!$export->addFileXMl14($dir,'producttag','product_tag')) {
                   $this->_errors[] = $this->l('Cannot create producttag.xml'); //extra
                }
                if(!$export->addFileXMl14($dir,'Feature','feature','id_feature',true))
                    $this->_errors[] = $this->l('Cannot create Feature.xml');
                if(!$export->addFileXMl14($dir,'FeatureValue','feature_value','id_feature_value',true))
                    $this->_errors[] = $this->l('Cannot create FeatureValue.xml');
                if (!$export->addFileXMl14($dir,'featureproduct','feature_product')) {
                   $this->_errors[] = $this->l('Cannot create featureproduct.xml'); // extra feature_product;
                }
                if(!$export->addFileXMl14($dir,'SpecificPrice','specific_price','id_specific_price',false))
                    $this->_errors[] = $this->l('Cannot create SpecificPrice.xml');
                if(!$export->addFileXMl14($dir,'Tax','tax','id_tax',true))
                    $this->_errors[] = $this->l('Cannot create Tax.xml');
                if(!$export->addFileXMl14($dir,'TaxRulesGroup','tax_rules_group','id_tax_rules_group',false))
                    $this->_errors[] = $this->l('Cannot create TaxRulesGroup.xml');
                if(!$export->addFileXMl14($dir,'TaxRule','tax_rule','id_tax_rule',false))
                    $this->_errors[] = $this->l('Cannot create TaxRule.xml');
                if(!$export->addFileXMl14($dir,'CustomizationField','customization_field','id_customization_field',true))
                    $this->_errors[]= $this->l('Cannot create CustomizationField.xml');
                if (!$export->addFileXMl14($dir,'accessory','accessory')) {
                   $this->_errors[] = $this->l('Cannot create accessory.xml'); //extra
                }
            }
            if(in_array('orders',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'OrderState','order_state','id_order_state',true))
                    $this->_errors[] = $this->l('Cannot create OrderState.xml');
                if(!$export->addFileXMl14($dir,'Cart','cart','id_cart',false))
                    $this->_errors[] = $this->l('Cannot create Cart.xml');
                if(!$export->addFileXMl14($dir,'Customization','customization','id_customization'))
                    $this->_errors[]= $this->l('Cannot create CustomizationField.xml');
                if(!$export->addFileXMl14($dir,'customizeddata','customized_data'))
                    $this->_errors[]= $this->l('Cannot create customizeddata.xml');
                if(!$export->addFileXMl14($dir,'Order','orders','id_order',false))
                    $this->_errors[] = $this->l('Cannot create Order.xml');
                if(!$export->addFileXMl14($dir,'OrderDetail','order_detail','id_order_detail',false))
                    $this->_errors[] = $this->l('Cannot create OrderDetail.xml');
                if(!$export->addFileXMl14($dir,'OrderSlip','order_slip','id_order_slip',false))
                    $this->_errors[] = $this->l('Cannot create OrderSlip.xml');
                if(!$export->addFileXMl14($dir,'OrderHistory','order_history','id_order_history',false))
                    $this->_errors[] = $this->l('Cannot create OrderHistory.xml');
                if(!$export->addFileXMl14($dir,'OrderMessage','order_message','id_order_message',true))
                    $this->_errors[] = $this->l('Cannot create OrderMessage.xml');
                if(!$export->addFileXMl14($dir,'OrderReturn','order_return','id_order_return',false))
                    $this->_errors[] = $this->l('Cannot create OrderReturn.xml');
                if(!$export->addFileXMl14($dir,'OrderReturn','order_return','id_order_return',false))
                    $this->_errors[] = $this->l('Cannot create OrderReturn.xml');
                if(!$export->addFileXMl14($dir,'Message','message','id_message',false))
                    $this->_errors[] = $this->l('Cannot create Message.xml');
            }
            if(in_array('cms_cateogories',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'CMSCategory','cms_category','id_cms_category',true))
                    $this->_errors[] = $this->l('Cannot create CMSCategory.xml');
            }
            if(in_array('cms',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'CMS','cms','id_cms',true))
                    $this->_errors[] = $this->l('Cannot create CMS.xml');
            }
            if(in_array('messages',$data_exports))
            {
                if(!$export->addFileXMl14($dir,'Contact','contact','id_contact',true))
                    $this->_errors[] = $this->l('Cannot create Contact.xml');
                if(!$export->addFileXMl14($dir,'CustomerThread','customer_thread','id_customer_thread',false))
                    $this->_errors[] = $this->l('Cannot create CustomerThread.xml');
                if(!$export->addFileXMl14($dir,'CustomerMessage','customer_message','id_customer_message',false))
                    $this->_errors[] = $this->l('Cannot create CustomerMessage.xml');
            }
            if(!$this->_errors)
            {
                $this->zipForderXml($zip_file_name);
                $content = $this->exportContent();
                $this->context->cookie->zip_file_name='';
                $this->context->cookie->write();
                $this->deleteForderXml($zip_file_name);
            }
        }
        return $this->_errors;
   }
   public function genSecure($size)
   {
        $chars = md5(time()); 
        $code = '';
        for ($i = 1; $i <= $size; ++$i)
        {
            $char= Tools::substr($chars, rand(0, Tools::strlen($chars) - 1), 1);
            if($char=='e')
                $char='a';
            $code .= $char;
        }
            
        return $code;
   }
   public static function upperFirstChar($t)
   {
        return Tools::ucfirst($t);
   }
   public function downloadFileZip($file_zip_name)
   {
        $cacheDir = dirname(__FILE__).'/cache/export/';
        ob_end_clean();
        ob_clean();
        header("Pragma: public"); // required
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
        header("Cache-Control: private",false); // required for certain browsers 
        header("Content-Transfer-Encoding: binary");
        header("Content-Length: ".filesize($cacheDir.$zip_file_name)); 
        header("Content-type: application/zip"); 
        header("Content-Disposition: attachment; filename=$zip_file_name"); 
        readfile($cacheDir.$zip_file_name);
        unlink($cacheDir.$zip_file_name);
        exit();
   }
   public function zipForderXml($file_name)
    {

        $dir_forder= dirname(__FILE__).'/cache/export/';
        $rootPath = realpath($dir_forder.$file_name);
        $zip = new ZipArchive();
        $zip->open($dir_forder.$file_name.'.zip', ZipArchive::CREATE | ZipArchive::OVERWRITE);
        // Create recursive directory iterator
        /** @var SplFileInfo[] $files */
        $files = new RecursiveIteratorIterator(

            new RecursiveDirectoryIterator($rootPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $name => $file)
        {
            if (!$file->isDir())
            {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($rootPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
    }
    public function deleteForderXml($file_name)
    {
        $this->context->cookie->export_sucss=1;

        $this->context->cookie->write();

        $dir_forder= dirname(__FILE__).'/cache/export/';
        if(!is_dir($dir_forder.$file_name))
            return true;
        foreach (glob($dir_forder.$file_name.'/*.*') as $filename) {
            @unlink($filename);
        }
        @rmdir($dir_forder.$file_name);
        if (ob_get_length() > 0) {
            ob_end_clean();
        }
        die(Tools::jsonEncode(
            array(
                'link_site_connector' => $this->getBaseLink().'modules/ets_pres2presconnector/cache/export/'.$file_name.'.zip',
            )
        ));
        return true;

    }
    public function ajaxPercentageExport()
    {
        if (ob_get_length() > 0) {
            ob_end_clean();
        }
        if(Tools::getValue('zip_file_name'))
            $zip_file_name = Tools::getValue('zip_file_name');
        elseif(isset($this->context->cookie->zip_file_name) && $this->context->cookie->zip_file_name)
            $zip_file_name =$this->context->cookie->zip_file_name;
        if(isset($zip_file_name)&& $zip_file_name)
        {
             $dir=dirname(__FILE__).'/cache/export/'.$zip_file_name;
             $totalItemExport= (int)file_get_contents($dir.'/totalexport.txt');
             $totalItemExported = (int)file_get_contents($dir.'/export.txt');
             if($totalItemExport && $totalItemExported)
             {
                    die(
                        Tools::jsonEncode(
                            array(
                                'percent'=> (float)round($totalItemExported*100/$totalItemExport,2),
                                'table'=>file_get_contents($dir.'/table_export.txt'),
                                'totalItemExport'=>$totalItemExport,
                                'totalItemExported'=>$totalItemExported,
                                'file'=>$this->context->cookie->zip_file_name,
                            )
                        )
                    );
             }
             
        }
        die(
            die(
                Tools::jsonEncode(
                    array(
                        'percent'=> 100,
                    )
                )
            )
        );
   }
   public function addCategoryFileXMl($dir,$multishop)
    {
        $roots=Db::getInstance()->executeS('SELECT c.id_category FROM '._DB_PREFIX_.'category c,'._DB_PREFIX_.'category_shop cs  where c.id_category=cs.id_category AND c.id_parent=0 group by c.id_category');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
		$xml_output .= '<entity_profile>'."\n";
        if($roots)
        {
            foreach($roots as $root)
            {
                $this->getXMlCategoriesTree($root['id_category'],$xml_output,$multishop);
            }
        }
        $xml_output .='</entity_profile>';
        if(!file_exists($dir.'/Category.xml'))
        {
            Configuration::updateValue('ETS_TABLE_EXPORT','category');
            file_put_contents($dir.'/Category.xml',$xml_output);
        }
        return true;
    }
    public function addCategoryFileXMl14($dir,$multishop)
    {
        $roots=Db::getInstance()->executeS('SELECT c.id_category FROM '._DB_PREFIX_.'category c  WHERE c.id_parent=0 group by c.id_category');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
		$xml_output .= '<entity_profile>'."\n";
        if($roots)
        {
            foreach($roots as $root)
            {
                $this->getXMlCategoriesTree($root['id_category'],$xml_output,true);
            }
        }
        $xml_output .='</entity_profile>';
        if(!file_exists($dir.'/Category.xml'))
        {
            Configuration::updateValue('ETS_TABLE_EXPORT','category');
            file_put_contents($dir.'/Category.xml',$xml_output);
        }
        return true;
    }
    public function getXMlCategoriesTree($id_root,&$xml_output,$multishop)
    {
        $sql = "SELECT c.*
                FROM "._DB_PREFIX_."category c
                ".(version_compare(_PS_VERSION_, '1.5', '>=')? "INNER JOIN "._DB_PREFIX_."category_shop cs on (c.id_category =cs.id_category ".(!$multishop ? ' AND cs.id_shop="'.(int)$this->context->shop->id.'"':'').")":"" )."
                WHERE c.id_category = ".(int)$id_root." GROUP BY c.id_category";
        $ssl=(Configuration::get('PS_SSL_ENABLED'));
        $base = $ssl ? 'https://'.Configuration::get('PS_SHOP_DOMAIN_SSL') : 'http://'.Configuration::get('PS_SHOP_DOMAIN');
        if($category = Db::getInstance()->getRow($sql))
        {            
            $xml_output .='<category>';
            if(file_exists(_PS_CAT_IMG_DIR_. (int)$id_root . '.jpg'))
            {
                $url = $base.__PS_BASE_URI__.'img/c/'.$id_root.'.jpg';
                $xml_output .='<link_image><![CDATA['.$url.']]></link_image>'."\n";
            }
            elseif(file_exists(_PS_CAT_IMG_DIR_. (int)$id_root . '-category_default.jpg'))
            {
                $url = $base.__PS_BASE_URI__.'img/c/'.$id_root.'-category_default.jpg';
                $xml_output .='<link_image><![CDATA['.$url.']]></link_image>'."\n";
            }
            elseif(file_exists(_PS_CAT_IMG_DIR_. (int)$id_root . '-medium_default.jpg'))
            {
                $url = $base.__PS_BASE_URI__.'img/c/'.$id_root.'-medium_default.jpg';
                $xml_output .='<link_image><![CDATA['.$url.']]></link_image>'."\n";
            }
            if(file_exists(_PS_CAT_IMG_DIR_. (int)$id_root . '_thumb.jpg'))
            {
                $url = $base.__PS_BASE_URI__.'img/c/'.$id_root.'_thumb.jpg';
                $xml_output .='<link_thumb><![CDATA['.$url.']]></link_thumb>'."\n";
            }
            foreach($category as $key=>$value)
            {
               $xml_output .='<'.$key.'><![CDATA['.$value.']]></'.$key.'>'."\n";
            }
            $datalanguages = Db::getInstance()->executeS('SELECT cl.*,l.iso_code FROM '._DB_PREFIX_.'category_lang cl,'._DB_PREFIX_.'lang l  WHERE cl.id_lang=l.id_lang AND cl.id_category='.(int)$id_root.(!$multishop ? ' AND cl.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            if($datalanguages && $datalanguages)
            {
                foreach($datalanguages as $datalanguage)
                {
                    $xml_output .= '<datalanguage iso_code="'.$datalanguage['iso_code'].'"'.($datalanguage['id_lang']==Configuration::get('PS_LANG_DEFAULT') ? ' default="1"':'').' >'."\n";
                    if($datalanguage)
                    {
                        foreach($datalanguage as $key => $value)
                        {
                            if($key!='iso_code')
                            {
                                $xml_output .='<'.$key.'><![CDATA['.$value.']]></'.$key.'>'."\n";
                            }
                        }
                    } 
                    $xml_output .='</datalanguage>'."\n";
                }
            }
            if(version_compare(_PS_VERSION_, '1.5', '>='))
            {
                $datashops = Db::getInstance()->executeS('SELECT s.id_shop,cs.* FROM '._DB_PREFIX_.'shop s ,'._DB_PREFIX_.'category_shop cs WHERE s.id_shop=cs.id_shop AND cs.id_category='.(int)$id_root.(!$multishop ? ' AND cs.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
                if($datashops && $datashops)
                {
                    foreach($datashops as $shop)
                    {
                        $xml_output .='<datashop id_shop="'.$shop['id_shop'].'"';
                        $xml_output .='></datashop>'."\n";
                    }
                }
            }
            $xml_output .='</category>';         
            $children = $this->getChildrenCategories2($id_root,$multishop);
            if($children)
            {
                foreach($children as $child)
                {
                    $this->getXMlCategoriesTree($child['id_category'],$xml_output,$multishop);
                
                }                    
            }
        }
    }
    public function getChildrenCategories2($id_root,$multishop)
    {
        $sql = "SELECT c.id_category
                FROM "._DB_PREFIX_."category c
                ".(version_compare(_PS_VERSION_, '1.5', '>=')? "INNER JOIN "._DB_PREFIX_."category_shop cs on (c.id_category =cs.id_category ".(!$multishop ? ' AND cs.id_shop="'.(int)$this->context->shop->id.'"':'').")":"" )."
                WHERE c.id_parent = ".(int)$id_root." GROUP BY c.id_category";
        return Db::getInstance()->executeS($sql);
    }
}