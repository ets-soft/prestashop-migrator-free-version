$(document).on('click','button[name="btnSubmitDownload"]',function(e){
    e.preventDefault();
    $('#module_form .popup_exporting').addClass('show');
    $('#module_form .popup_uploading .export-wapper-percent').css('transition','all 5s ease 0s');
    $('#module_form .popup_exporting .export-wapper-percent').css('width','1%');
    ajaxPercentExport = setInterval(function(){ ajaxPercentageExport() }, 1000);              
    $('.ets_datamaster_error').remove();
    $(this).next('.export-sussec').hide();
    processExportData(0);
});
function processExportData(reload)
{
    var formData = new FormData($('button[name="btnSubmitDownload"]').parents('form').get(0));
    formData.append('btnSubmitDownload', '1');
    formData.append('submitExportReload', reload);
    $.ajax({
        url: ETS_CONNECTOR_URL_AJAX,
        data: formData,
        type: 'post',
        dataType: 'json',
        processData: false,
        contentType: false,
        success: function(json){
            if(ajaxPercentExport)
                clearInterval(ajaxPercentExport);
            if(json.error)
            {
                $('#module_form .form-wrapper').append('<div class="ets_datamaster_error">'+json.errors+'</div>');
                $('#module_form .popup_exporting').removeClass('show');
            }                
            else
            {
                $('#module_form .popup_exporting .export-wapper-percent').css('transition','all 1s ease 0s');
                $('#module_form .popup_exporting .export-wapper-percent').css('width','100%');
                $('#module_form .panel-footer').hide();
                setTimeout(function(){
                    $('#module_form .popup_exporting').removeClass('show');
                    $('button[name="btnSubmitDownload"]').next('.export-sussec').show();
                    $('button[name="btnSubmitDownload"]').next('.export-sussec').find('a').attr('href',json.link_site_connector);   
                }, 1000);
            }
        },
        error: function(xhr, status, error)
        {
             processExportData(1)      
        }
    });
}
function ajaxPercentageExport()
{
    $.ajax({
        url: '',
        data: 'ajax_percentage_export=1',
        type: 'post',
        dataType: 'json',
        success: function(json){
            if(json.percent>0 && json.percent<100)
            {
                $('#module_form .popup_exporting .export-wapper-percent').css('transition','all 3s ease 0s');
                $('#module_form .popup_exporting .export-wapper-percent').css('width',json.percent+'%');
                $('#module_form .popup_exporting .percentage_export').html(json.percent+'%');
            }
            if(json.table)
                    $('#module_form .popup_uploading .percentage_export_table').html('Exporting data from table <strong>"'+json.table+'"</strong>');
        },
        error: function(xhr, status, error)
        {             
        }
    });
}