<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses. 
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 * 
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2018 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

class Pres2PresConnectorExtraExport extends Module
{
    public $pres_version;
	public	function __construct()
	{
		parent::__construct();
        if(version_compare(_PS_VERSION_, '1.7', '>='))
            $this->pres_version=1.7;
        elseif(version_compare(_PS_VERSION_, '1.7', '<') && version_compare(_PS_VERSION_, '1.6', '>=') )
            $this->pres_version=1.6;
        elseif(version_compare(_PS_VERSION_, '1.6', '<') && version_compare(_PS_VERSION_, '1.5', '>=') )
            $this->pres_version=1.5;
        elseif(version_compare(_PS_VERSION_, '1.5', '<'))
            $this->pres_version=1.4;
        $this->context = Context::getContext();
        $this->_module = Module::getInstanceByName('ets_pres2presconnector');
	}
    //customization_field
    public function exportInfo($dir)
    {
        $data_exports=explode(',',$this->_module->data_exports);
        $multishop = (int)in_array('shops',$data_exports) && Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml_output .= '<entity_profile>'."\n";	
        $xml_output .='<domain>'.(isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : $_SERVER['HTTP_HOST']).'</domain>'."\n";
        $xml_output .='<pres_version>'._PS_VERSION_.'</pres_version>'."\n";
        $xml_output .='<cookie_key>'._COOKIE_KEY_.'</cookie_key>'."\n";
        $link_site= '';
        $totalItem =0;
        $export_data= '';
        if($multishop)
        {
            $shops= Db::getInstance()->executeS('SELECT * FROM '._DB_PREFIX_.'shop');
            if($shops)
            {
                foreach($shops as $shop)
                {
                    $shop_obj= new Shop($shop['id_shop']);
                    $base = (Configuration::get('PS_SSL_ENABLED') ? 'https://'.$shop_obj->domain_ssl : 'http://'.$shop_obj->domain);
                    $link_site .= $base.$shop_obj->getBaseURI().',';  
                }
            }
            $countShop = count($shops);
            $countShopGroup = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'shop_group');
            $countShopUrl = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'shop_url');
            $totalItem +=$countShop+$countShopGroup+$countShopUrl;
            $xml_output .='<countshop>'.(int)$countShop.'</countshop>'."\n";
            $xml_output .='<countextrashop>'.((int)$countShopGroup+(int)$countShopUrl).'</countextrashop>'."\n";
            $export_data .='shops,';
        }
        else
        {
            if($this->pres_version==1.4)
            {
                $link_site = Context::getContext()->link->getPageLink('index.php',true);
            }
            else
            {
                $base = (Configuration::get('PS_SSL_ENABLED') ? 'https://'.Context::getContext()->shop->domain_ssl : 'http://'.Context::getContext()->shop->domain);
                $link_site= $base.Context::getContext()->shop->getBaseURI(); 
            }
        }
        $xml_output .='<link_site>'.trim($link_site,',').'</link_site>'."\n";
        $countLang = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'lang');
        $xml_output .='<countlang>'.(int)$countLang.'</countlang>'."\n";
        $totalItem +=$countLang;
        $countCurrency = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'currency');
        $xml_output .='<countcurrency>'.(int)$countCurrency.'</countcurrency>'."\n";
        $countZone = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'zone');
        $xml_output .='<countzone>'.(int)$countZone.'</countzone>'."\n";
        $countCountry = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'country');
        $xml_output .='<countcountry>'.(int)$countCountry.'</countcountry>'."\n";
        $countState = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'state');
        $xml_output .='<countstate>'.(int)$countState.'</countstate>'."\n";
        $totalItem +=$countCurrency+$countZone+$countCountry+$countState;
        if(in_array('employees',$data_exports))
        {
            $countEmployee = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'employee');
            $xml_output .='<countemployee>'.(int)$countEmployee.'</countemployee>'."\n";
            $totalItem +=$countEmployee;
            $export_data .='employees,';
        }
        if(in_array('categories',$data_exports))
        {
            $countCategory = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'category c
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'category_shop cs ON (c.id_category=cs.id_category)':'').(!$multishop ? ' WHERE cs.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $id_root_category = Db::getInstance()->getValue('SELECT id_category FROM '._DB_PREFIX_.'category WHERE is_root_category=1');
            $xml_output .='<countcategory>'.(int)$countCategory.'</countcategory>'."\n";
            $xml_output .='<rootcategory>'.(int)$id_root_category.'</rootcategory>'."\n";
            $totalItem +=$countCategory;
            $export_data .='categories,';
        }
        if(in_array('customers',$data_exports))
        {
            $countCustomer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer c
            '.(!$multishop ? ' WHERE c.id_shop="'.(int)Context::getContext()->shop->id.'" AND c.deleted=0':' WHERE c.deleted=0'));
            $countGroup = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'group');
            $countAddress =Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'address');
            $count_customer_group= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer_group');
            $totalItem +=$countCustomer+$countGroup+$countAddress+$count_customer_group;
            $xml_output .='<countcustomer>'.(int)$countCustomer.'</countcustomer>'."\n";
            $xml_output .='<countextracustomer>'.((int)$countGroup+$countAddress+$count_customer_group).'</countextracustomer>'."\n";
            $export_data .='customers,';
        }
        if(in_array('manufactures',$data_exports))
        {
            $countManufacturer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'manufacturer m
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'manufacturer_shop ms ON (m.id_manufacturer=ms.id_manufacturer)':'').(!$multishop ? ' WHERE ms.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countmanufacturer>'.(int)$countManufacturer.'</countmanufacturer>'."\n";
            $totalItem +=$countManufacturer;
            $export_data .='manufactures,';
        }
        if(in_array('suppliers',$data_exports))
        {
            $countSupplier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'supplier s
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'supplier_shop ss ON (s.id_supplier=ss.id_supplier)':'').(!$multishop ? ' WHERE ss.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countsupplier>'.(int)$countSupplier.'</countsupplier>'."\n";
            $totalItem +=$countSupplier;
            $export_data .='suppliers,';
        }
        if(in_array('carriers',$data_exports))
        {
            $countCarrier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier c
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'carrier_shop cs ON (c.id_carrier=cs.id_carrier)':'').(!$multishop ? ' WHERE cs.id_shop="'.(int)Context::getContext()->shop->id.'" AND c.deleted=0':' WHERE c.deleted=0'));
            $countCarrierDeleted =Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier WHERE deleted=1');
            $count_carrier_zone= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier_zone');
            $countRangePrice = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'range_price');
            $countRangeWeight = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'range_weight');
            $countDelivery = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'delivery');
            $totalItem +=$countCarrier+$countZone+$countRangePrice+$countRangeWeight+$countDelivery+$countCarrierDeleted+$count_carrier_zone;
            $xml_output .='<countcarrier>'.(int)$countCarrier.'</countcarrier>'."\n";
            $xml_output .='<countextracarrier>'.($countZone+$countRangePrice+$countRangeWeight+$countDelivery+$countCarrierDeleted+$count_carrier_zone).'</countextracarrier>'."\n";
            $export_data .='carriers,';
        }
        if(in_array('cart_rules',$data_exports))
        {
            $countCartRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cart_rule');
            $xml_output .='<countcartrule>'.(int)$countCartRule.'</countcartrule>'."\n";
            $totalItem +=$countCartRule;
            $export_data .='cart_rules,';
        }
        if(in_array('catelog_rules',$data_exports))
        {
            $countSpecificPriceRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'specific_price_rule');
            $xml_output .='<countspecificpriceRule>'.(int)$countSpecificPriceRule.'</countspecificpriceRule>'."\n";
            $totalItem +=$countSpecificPriceRule;
            $export_data .='catelog_rules,';
        }
        if(in_array('vouchers',$data_exports))
        {
            $countvoucher = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'discount');
            $xml_output .='<countvoucher>'.(int)$countvoucher.'</countvoucher>'."\n";
            $totalItem +=$countvoucher;
            $export_data .='vouchers,';
        }
        if(in_array('products',$data_exports))
        {
            $count_category_product= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'category_product');
            $count_product_attribute_combination = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_attribute_combination');
            $count_product_attribute_image = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_attribute_image');
            $count_product_tag= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_tag');
            $count_feature_product= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature_product');
            $count_product_supplier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_supplier');
            $count_stock_available= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'stock_available');
            $count_customization_field= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customization_field');
            if(in_array('carriers',$data_exports))
            {
                $count_product_carrier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_carrier');
            }
            else
                $count_product_carrier =0;
            $count_accessory= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'accessory'); 
            $countProduct= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product p
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'product_shop ps ON (p.id_product=ps.id_product)':'').(!$multishop ? ' WHERE ps.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $countCombination= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product_attribute');
            $countImage= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'image');
            $countAttributeGroup = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'attribute_group');
            $countAttribute = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'attribute');
            $countFeature = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature');
            $countFeatureValue = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature_value');
            $countSpecificPrice = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'specific_price');
            $countTaxRulesGroup= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tax_rules_group');
            $countTaxRule = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tax_rule');
            $countTag = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tag');
            if(version_compare(_PS_VERSION_, '1.5', '>='))
                $countStockAvailable= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'stock_available');
            else
                $countStockAvailable=0;
            $countTax = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'tax');
            $totalItem +=$count_accessory+$count_product_carrier+$count_customization_field+$count_stock_available+$count_product_supplier+$count_feature_product+$count_product_tag+$count_product_attribute_image+$count_product_attribute_combination+$count_category_product+ $countProduct+$countImage+$countCombination+$countAttributeGroup+$countAttribute+$countFeature+$countFeatureValue+$countSpecificPrice+$countTaxRulesGroup+$countTaxRule+$countTax;
            if(version_compare(_PS_VERSION_, '1.5', '>='))
                $totalItem += $countStockAvailable;
            $xml_output .='<countproduct>'.(int)$countProduct.'</countproduct>'."\n";
            $xml_output .='<countextraproduct>'.($count_accessory+$count_product_carrier+$count_customization_field+$count_stock_available+$count_product_supplier+$count_feature_product+$count_product_tag+$count_product_attribute_image+$count_product_attribute_combination+$count_category_product+$countImage+$countCombination+$countAttributeGroup+$countAttribute+$countFeature+$countFeatureValue+$countSpecificPrice+$countTaxRulesGroup+$countTaxRule+$countTax).'</countextraproduct>'."\n";
            $export_data .='products,';
        }
        if(in_array('orders',$data_exports))
        {
            $count_customization = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customization');
            $count_customized_data = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customized_data');
            $count_message= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'message');
            $countOrder = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'orders'.($multishop ? ' WHERE id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $countOrderState= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_state');
            $countCart = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cart');
            $countOrderDetail = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_detail');
            $countOrderInvoice = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_invoice');
            $countOrderSlip = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_slip');
            $countOrderCarrier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_carrier');
            $countOrderCartRule = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_cart_rule');
            $countOrderHistory = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_history');
            $countOrderMessage = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_message');
            $countOrderPayment = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_payment');
            $countOrderReturn  = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_return');
            $totalItem +=$count_message+$count_customized_data+$count_customization+$countOrder+$countOrderState+$countCart+$countOrderDetail+$countOrderInvoice+$countOrderSlip+$countOrderCarrier+$countOrderCartRule+$countOrderHistory+$countOrderMessage+$countOrderPayment+$countOrderReturn;
            $xml_output .='<countorder>'.(int)$countOrder.'</countorder>'."\n";
            $xml_output .='<countextraorder>'.($count_message+$count_customized_data+$count_customization+$countOrderState+$countCart+$countOrderDetail+$countOrderInvoice+$countOrderSlip+$countOrderCarrier+$countOrderCartRule+$countOrderHistory+$countOrderMessage+$countOrderPayment+$countOrderReturn).'</countextraorder>'."\n";
            $export_data .='orders,';
        }
        if(in_array('cms_cateogories',$data_exports))
        {
            $countcmscategory = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms_category c
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'cms_category_shop cs ON (c.id_cms_category=cs.id_cms_category)':'').(!$multishop ? ' WHERE cs.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countcmscategory>'.(int)$countcmscategory.'</countcmscategory>'."\n";
            $export_data .='cms_cateogories,';
            $totalItem +=$countcmscategory;
        }
        if(in_array('cms',$data_exports))
        {
            $countcms = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms');
            $xml_output .='<countcms>'.(int)$countcms.'</countcms>'."\n";
            $export_data .='cms,';
            $totalItem +=$countcms;
        }
        if(in_array('messages',$data_exports))
        {
            $countMessage = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer_thread');
            $count_contact = Db::getInstance()->getValue('SELECT * FROM '._DB_PREFIX_.'contact');
            $countCustomerMessage = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customer_message');
            $totalItem +=$count_contact+$countMessage+$countCustomerMessage;
            $xml_output .='<countmessage>'.$countMessage.'</countmessage>'."\n";
            $xml_output .='<countextramessage>'.($count_contact+$countCustomerMessage).'</countextramessage>'."\n";
            $export_data .='messages,';
        }
        $xml_output .='<totalitem>'.(int)$totalItem.'</totalitem>'."\n";
        $xml_output .='<exporteddata>'.trim($export_data,',').'</exporteddata>'."\n";
        file_put_contents($dir.'/totalexport.txt',$totalItem);
        $xml_output .= '</entity_profile>'."\n";
        return $xml_output;
    }
}