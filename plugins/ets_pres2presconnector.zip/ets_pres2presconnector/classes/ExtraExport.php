<?php
/**
 * 2007-2018 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses. 
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 * 
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2018 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

class Pres2PresConnectorExtraExport extends Module
{
    public $pres_version;
	public	function __construct()
	{
		parent::__construct();
        if(version_compare(_PS_VERSION_, '1.7', '>='))
            $this->pres_version=1.7;
        elseif(version_compare(_PS_VERSION_, '1.7', '<') && version_compare(_PS_VERSION_, '1.6', '>=') )
            $this->pres_version=1.6;
        elseif(version_compare(_PS_VERSION_, '1.6', '<') && version_compare(_PS_VERSION_, '1.5', '>=') )
            $this->pres_version=1.5;
        elseif(version_compare(_PS_VERSION_, '1.5', '<'))
            $this->pres_version=1.4;
        $this->context = Context::getContext();
        $this->_module = Module::getInstanceByName('ets_pres2presconnector');
	}
    //customization_field
    public function exportInfo($dir)
    {
        $data_exports=explode(',',$this->_module->data_exports);
        $multishop = (int)in_array('shops',$data_exports) && Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE');
        $xml_output = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
        $xml_output .= '<entity_profile>'."\n";	
        $xml_output .='<domain>'.(isset($_SERVER['HTTP_X_FORWARDED_HOST']) ? $_SERVER['HTTP_X_FORWARDED_HOST'] : $_SERVER['HTTP_HOST']).'</domain>'."\n";
        $xml_output .='<pres_version>'._PS_VERSION_.'</pres_version>'."\n";
        $xml_output .='<cookie_key>'._COOKIE_KEY_.'</cookie_key>'."\n";
        $link_site= '';
        $totalItem =0;
        $export_data= '';
        if($multishop)
        {
            $shops= Db::getInstance()->executeS('SELECT * FROM '._DB_PREFIX_.'shop');
            if($shops)
            {
                foreach($shops as $shop)
                {
                    $shop_obj= new Shop($shop['id_shop']);
                    $base = (Configuration::get('PS_SSL_ENABLED') ? 'https://'.$shop_obj->domain_ssl : 'http://'.$shop_obj->domain);
                    $link_site .= $base.$shop_obj->getBaseURI().',';  
                }
            }
            $countShop = count($shops);
            $countShopGroup = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'shop_group');
            $countShopUrl = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'shop_url');
            $totalItem +=$countShop+$countShopGroup+$countShopUrl;
            $xml_output .='<countshop>'.(int)$countShop.'</countshop>'."\n";
            $xml_output .='<countextrashop>'.((int)$countShopGroup+(int)$countShopUrl).'</countextrashop>'."\n";
            $export_data .='shops,';
        }
        else
        {
            if($this->pres_version==1.4)
            {
                $link_site = Context::getContext()->link->getPageLink('index.php',true);
            }
            else
            {
                $base = (Configuration::get('PS_SSL_ENABLED') ? 'https://'.Context::getContext()->shop->domain_ssl : 'http://'.Context::getContext()->shop->domain);
                $link_site= $base.Context::getContext()->shop->getBaseURI(); 
            }
        }
        $xml_output .='<link_site>'.trim($link_site,',').'</link_site>'."\n";
        $countLang = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'lang');
        $xml_output .='<countlang>'.(int)$countLang.'</countlang>'."\n";
        $totalItem +=$countLang;
        $countCurrency = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'currency');
        $xml_output .='<countcurrency>'.(int)$countCurrency.'</countcurrency>'."\n";
        $countZone = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'zone');
        $xml_output .='<countzone>'.(int)$countZone.'</countzone>'."\n";
        $countCountry = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'country');
        $xml_output .='<countcountry>'.(int)$countCountry.'</countcountry>'."\n";
        $countState = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'state');
        $xml_output .='<countstate>'.(int)$countState.'</countstate>'."\n";
        $totalItem +=$countCurrency+$countZone+$countCountry+$countState;
        if(in_array('employees',$data_exports))
        {
            $countEmployee = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'employee');
            $xml_output .='<countemployee>'.(int)$countEmployee.'</countemployee>'."\n";
            $totalItem +=$countEmployee;
            $export_data .='employees,';
        }
        if(in_array('categories',$data_exports))
        {
            $countCategory = Db::getInstance()->getValue('
            SELECT count(*) FROM '._DB_PREFIX_.'category c
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'category_shop cs ON (c.id_category=cs.id_category)':'').(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE cs.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $id_root_category = Db::getInstance()->getValue('SELECT id_category FROM '._DB_PREFIX_.'category WHERE is_root_category=1');
            $xml_output .='<countcategory>'.(int)$countCategory.'</countcategory>'."\n";
            $xml_output .='<rootcategory>'.(int)$id_root_category.'</rootcategory>'."\n";
            $count_category_group = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'category_group');                        
            $totalItem += $countCategory +$count_category_group;
            $xml_output .='<counttotalcategory>'.($countCategory +$count_category_group).'</counttotalcategory>'."\n";
            $export_data .='categories,';
        }
        if(in_array('customers',$data_exports))
        {
            $countCustomer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer c
            '.(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE c.id_shop="'.(int)Context::getContext()->shop->id.'" AND c.deleted=0':' WHERE c.deleted=0'));
            $xml_output .='<countcustomer>'.(int)$countCustomer.'</countcustomer>'."\n";
            $countGroup = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'group');
            $xml_output .='<countgroup>'.(int)$countGroup.'</countgroup>'."\n";
            $countAddress =Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'address');
            $xml_output .='<countaddress>'.(int)$countAddress.'</countaddress>'."\n";
            $count_category_group = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'category_group');
            $xml_output .='<count_category_group_customer>'.(int)$count_category_group.'</count_category_group_customer>';
            $totatCustomer=$count_category_group+$countCustomer+$countGroup+$countAddress;
            $totalItem += $totatCustomer;
            $xml_output .='<counttotalcustomer>'.(int)$totatCustomer.'</counttotalcustomer>'."\n";
            $export_data .='customers,';
        }
        if(in_array('manufactures',$data_exports))
        {
            $countManufacturer = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'manufacturer m
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'manufacturer_shop ms ON (m.id_manufacturer=ms.id_manufacturer)':'').(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE ms.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countmanufacturer>'.(int)$countManufacturer.'</countmanufacturer>'."\n";
            $totalItem +=$countManufacturer;
            $export_data .='manufactures,';
        }
        if(in_array('suppliers',$data_exports))
        {
            $countSupplier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'supplier s
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'supplier_shop ss ON (s.id_supplier=ss.id_supplier)':'').(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE ss.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countsupplier>'.(int)$countSupplier.'</countsupplier>'."\n";
            $totalItem += $countSupplier;
            $export_data .='suppliers,';
        }
        if(in_array('carriers',$data_exports))
        {
            $countCarrier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier c
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'carrier_shop cs ON (c.id_carrier=cs.id_carrier)':'').(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE cs.id_shop="'.(int)Context::getContext()->shop->id.'" AND c.deleted=0':' WHERE c.deleted=0'));
            $xml_output .='<countcarrier>'.(int)$countCarrier.'</countcarrier>'."\n";
            $countCarrierZone = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier_zone');
            $xml_output .='<countcarrierzone>'.(int)$countCarrierZone.'</countcarrierzone>'."\n";
            $countCarrierGroup = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'carrier_group');
            $countRangePrice = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'range_price');
            $xml_output .='<countrangeprice>'.(int)$countRangePrice.'</countrangeprice>'."\n";
            $xml_output .='<countcarriergroup>'.(int)$countCarrierGroup.'</countcarriergroup>';
            $countRangeWeight = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'range_weight');
            $xml_output .='<countrangeweight>'.(int)$countRangeWeight.'</countrangeweight>'."\n";
            $countDelivery = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'delivery');
            $xml_output .='<countdelivery>'.(int)$countDelivery.'</countdelivery>'."\n";
            $totalCarrer = $countCarrierGroup+$countCarrierZone+ $countCarrier+$countZone+$countRangePrice+$countRangeWeight+$countDelivery;
            $totalItem += $totalCarrer;
            $xml_output .='<counttotalcarrier>'.(int)$totalCarrer.'</counttotalcarrier>'."\n";
            $export_data .='carriers,';
        }
        if(in_array('cart_rules',$data_exports))
        {
            $countCartRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cart_rule');
            $xml_output .='<countcartrule>'.(int)$countCartRule.'</countcartrule>'."\n";
            $totalItem +=$countCartRule;
            $export_data .='cart_rules,';
        }
        if(in_array('catelog_rules',$data_exports))
        {
            $countSpecificPriceRule = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'specific_price_rule');
            $xml_output .='<countspecificpriceRule>'.(int)$countSpecificPriceRule.'</countspecificpriceRule>'."\n";
            $totalItem +=$countSpecificPriceRule;
            $export_data .='catelog_rules,';
        }
        if(in_array('vouchers',$data_exports))
        {
            $countvoucher = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'discount');
            $xml_output .='<countvoucher>'.(int)$countvoucher.'</countvoucher>'."\n";
            $totalItem += $countvoucher;
            $export_data .='vouchers,';
        }
        if(in_array('products',$data_exports))
        {
            $countProduct= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product p
            '.(version_compare(_PS_VERSION_, '1.5', '>=') ? ' INNER JOIN '._DB_PREFIX_.'product_shop ps ON (p.id_product=ps.id_product)':'').(!$multishop && version_compare(_PS_VERSION_, '1.5', '>=') ? ' WHERE ps.id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $countCombination= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product_attribute');
            $countImage= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'image');
            $countAttributeGroup = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'attribute_group');
            $countAttribute = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'attribute');
            $countFeature = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature');
            $countFeatureValue = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature_value');
            $countSpecificPrice = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'specific_price');
            $countTaxRulesGroup= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tax_rules_group');
            $countTaxRule = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tax_rule');
            $countTag = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'tag');
            if(version_compare(_PS_VERSION_, '1.5', '>='))
                $countStockAvailable= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'stock_available');
            $countTax = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'tax');
            $xml_output .='<countproduct>'.(int)$countProduct.'</countproduct>'."\n";
            $xml_output .='<countimage>'.(int)$countImage.'</countimage>'."\n";
            $xml_output .='<countcombination>'.(int)$countCombination.'</countcombination>'."\n";
            $xml_output .='<countattributegroup>'.(int)$countAttributeGroup.'</countattributegroup>'."\n";
            $xml_output .='<countattribute>'.(int)$countAttribute.'</countattribute>'."\n";
            $xml_output .='<countfeature>'.(int)$countFeature.'</countfeature>'."\n";
            $xml_output .='<countfeaturevalue>'.(int)$countFeatureValue.'</countfeaturevalue>'."\n";
            $xml_output .='<countspecificprice>'.(int)$countSpecificPrice.'</countspecificprice>'."\n";
            $xml_output .='<counttaxrulesgroup>'.(int)$countTaxRulesGroup.'</counttaxrulesgroup>'."\n";
            $xml_output .='<counttaxrule>'.(int)$countTaxRule.'</counttaxrule>'."\n";
            $count_accessory= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'accessory');
            $xml_output .='<counttag>'.(int)$countTag.'</counttag>'."\n";
            if(version_compare(_PS_VERSION_, '1.5', '>='))
                 $xml_output .='<countstockavailable>'.(int)$countStockAvailable.'</countstockavailable>'."\n";
            $xml_output .='<counttax>'.(int)$countTax.'</counttax>'."\n";
            $countProductCategory = Db::getInstance()->getValue('SELECT count(*) FROM category_product');
            $count_product_attribute_image = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product_attribute_image');
            $count_product_tag= Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'product_tag');
            $count_feature_product = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'feature_product');
            $count_product_supplier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_supplier');
            $count_product_carrier = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_carrier');
            $countcustomization_field = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customization_field');
            $countCustomization = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customization');
            $countproductattributecombination= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'product_attribute_combination');
            $counttotalproduct=$countproductattributecombination+$countTag+$countCustomization+$countcustomization_field+ $count_accessory+$count_product_supplier+$count_feature_product+$count_product_tag+$count_product_attribute_image+ $countProduct+$countImage+$countCombination+$countAttributeGroup+$countAttribute+$countFeature+$countFeatureValue+$countSpecificPrice+$countTaxRulesGroup+$countTaxRule+$countTax+$count_product_carrier+$countProductCategory*2;
            $totalItem += $counttotalproduct;
            $xml_output .='<counttotalproduct>'.(int)$counttotalproduct.'</counttotalproduct>'."\n";
            if(version_compare(_PS_VERSION_, '1.5', '>='))
                $totalItem += $countStockAvailable;
            $export_data .='products,';
        }
        if(in_array('orders',$data_exports))
        {
            $countOrder = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'orders'.($multishop ? ' WHERE id_shop="'.(int)Context::getContext()->shop->id.'"':''));
            $xml_output .='<countorder>'.(int)$countOrder.'</countorder>'."\n";
            $countOrderState= Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_state');
            $xml_output .='<countorderstate>'.(int)$countOrderState.'</countorderstate>'."\n";
            $countCart = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cart');
            $xml_output .='<countcart>'.(int)$countCart.'</countcart>'."\n";
            $countOrderDetail = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_detail');
            $xml_output .='<countorderdetail>'.(int)$countOrderDetail.'</countorderdetail>'."\n";
            $countOrderInvoice = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_invoice');
            $xml_output .='<countorderinvoice>'.(int)$countOrderInvoice.'</countorderinvoice>'."\n";
            $countOrderSlip = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_slip');
            $xml_output .='<countorderslip>'.(int)$countOrderSlip.'</countorderslip>'."\n";
            $countOrderCarrier = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_carrier');
            $xml_output .='<countordercarrier>'.(int)$countOrderCarrier.'</countordercarrier>'."\n";
            $countOrderCartRule = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_cart_rule');
            $xml_output .='<countordercartrule>'.(int)$countOrderCartRule.'</countordercartrule>'."\n";
            $countOrderHistory = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'order_history');
            $xml_output .='<countorderhistory>'.(int)$countOrderHistory.'</countorderhistory>'."\n";
            $countOrderMessage = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_message');
            $xml_output .='<countordermessage>'.(int)$countOrderMessage.'</countordermessage>'."\n";
            $countOrderPayment = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_payment');
            $xml_output .='<countorderpayment>'.(int)$countOrderPayment.'</countorderpayment>'."\n";
            $countOrderReturn  = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'order_return');
            $xml_output .='<countorderreturn>'.(int)$countOrderReturn.'</countorderreturn>'."\n";
            $countMessage =Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'message');
            $totalItem += $countMessage+ $countOrder+$countOrderState+$countCart+$countOrderDetail+$countOrderInvoice+$countOrderSlip+$countOrderCarrier+$countOrderCartRule+$countOrderHistory+$countOrderMessage+$countOrderPayment+$countOrderReturn;
            $export_data .='orders,';
        }
        if(in_array('cms_cateogories',$data_exports))
        {
            $countcmscategory = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms_category c');
            $xml_output .='<countcmscategory>'.(int)$countcmscategory.'</countcmscategory>'."\n";
            $export_data .='cms_cateogories,';
            $totalItem += $countcmscategory;
        }
        if(in_array('cms',$data_exports))
        {
            $countcms = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'cms');
            $xml_output .='<countcms>'.(int)$countcms.'</countcms>'."\n";
            $export_data .='cms,';
            $totalItem += $countcms;
        }
        if(in_array('messages',$data_exports))
        {
            $countMessage = Db::getInstance()->getValue('SELECT count(*) FROM '._DB_PREFIX_.'customer_thread');
            $xml_output .='<countmessage>'.(int)$countMessage.'</countmessage>'."\n";
            $countContact = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'contact');
            $countcustomermessage = Db::getInstance()->getValue('SELECT COUNT(*) FROM '._DB_PREFIX_.'customer_message');
            $export_data .='messages,';
            $totalItem += $countMessage+$countContact+$countcustomermessage;
        }
        $xml_output .='<totalitem>'.(int)$totalItem.'</totalitem>'."\n";
        $xml_output .='<exporteddata>'.trim($export_data,',').'</exporteddata>'."\n";
        file_put_contents($dir.'/totalexport.txt',$totalItem);
        $xml_output .= '</entity_profile>'."\n";
        return $xml_output;
    }
}