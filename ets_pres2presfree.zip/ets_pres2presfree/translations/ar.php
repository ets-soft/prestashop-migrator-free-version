<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_pres2pres}prestashop>ets_pres2pres_671ada0951f0d03fd3e35cee481159b0'] = 'Prestashop Migrator';
